<?php
include_once "config.php";

class forumController {
  function getForum(array $values) {
    $conn = config::getConnection();
    $sql = "select * from Forums inner join Users on authorId = Users.userId where forumId = :id";
    $query = $conn->prepare($sql);
    $query->execute($values);
    $result = $query->fetch();
    return $result;
  }

  function getAllForums() {
    $conn = config::getConnection();
    $sql = "select * from Forums inner join Users on authorId = Users.userId";
    $query = $conn->prepare($sql);
    $query->execute();
    $result = $query->fetchAll();
    return $result;
  }

  function getRecentForums(int $total) {
    $conn = config::getConnection();
    $sql = "select * from Forums inner join Users on userId = authorId order by dateForum desc limit 0, :total";
    $query = $conn->prepare($sql);
    $query->bindValue(":total", $total, PDO::PARAM_INT);
    $query->execute();
    $result = $query->fetchAll();
    return $result;
  }

  function deleteForum(int $id) {
    $conn = config::getConnection();
    $sql = "delete from Forums where forumId = :id";
    $query = $conn->prepare($sql);
    $query->bindValue(":id", $id, PDO::PARAM_INT);
    $query->execute();
    return $result;
  }
}