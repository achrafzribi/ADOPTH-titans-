<?php
	include '../config.php';
	include_once '../Model/events.php';
	class eventC {
		function afficherevents(){
			$sql="SELECT * FROM events";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMeesage());
			}
		}
		function supprimerevent($event_name){
			$sql="DELETE FROM events WHERE event_name=:event_name";
			$db = config::getConnexion();
			$req=$db->prepare($sql);
			$req->bindValue(':event_name', $event_name);
			try{
				$req->execute();
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMeesage());
			}
		}
		function ajouterevent($events){
			$sql="insert into events VALUES (null,'$events->event_name','$events->event_date','$events->animals','$events->event_description',null,'$events->event_place')";
			$db = config::getConnexion();
			try{
				$db->query($sql);		
			}
			catch (Exception $e){
				echo 'Erreur: '.$e->getMessage();
			}			
		}
		function recupererevent($event_id){
			$sql="SELECT * from events where event_id=$event_id";
			$db = config::getConnexion();
			try{
				$query=$db->prepare($sql);
				$query->execute();

				$events=$query->fetch();
				return $events;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
		}
		
		function modifierevent($events, $event_id){
			try {
				$db = config::getConnexion();
				$sql="UPDATE events
				SET
				event_id='$events->event_id',
				event_name='$events->event_name',
				event_date='$events->event_date',
				animals='$events->animals',
				event_description='$events->event_description',
				event_place='$events->event_place'
				WHERE event_id='event_id'";

				$db->query($sql);
			} catch (PDOException $e) {
				$e->getMessage();
			}
		}

	}
?>