<?php
	include '../config.php';
	include_once '../Model/participants.php';
	class participantC {
		function afficherparticipants(){
			$sql="SELECT * FROM participants";
			$db = config::getConnexion();
			try{
				$liste2 = $db->query($sql);
				return $liste2;
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMeesage());
			}
		}
		function supprimerparticipant($participant_id){
			$sql="DELETE FROM participants WHERE participant_id=:participant_id";
			$db = config::getConnexion();
			$req=$db->prepare($sql);
			$req->bindValue(':participant_id', $participant_id);
			try{
				$req->execute();
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMeesage());
			}
		}
		function ajouterparticipant($participants){
			$sql="insert into participants VALUES ('$participants->participant_id','$participants->participant_name','$participants->participant_telephone','$participants->participant_animal')";
				$db = config::getConnexion();
				try{
					$db->query($sql);
				}
				catch (Exception $e){
					echo 'Erreur: '.$e->getMessage();
				}			
			}
			
		function recupererparticipant($participant_id){
			$sql="SELECT * from participants where participant_id=$participant_id";
			$db = config::getConnexion();
			try{
				$query=$db->prepare($sql);
				$query->execute();

				$events=$query->fetch();
				return $participants;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
		}
		
		function modifierparticipant($participants, $participant_id){
			try {
				$db = config::getConnexion();
				$query = $db->prepare(
					'UPDATE events SET 
						participant_id= :participant_id, 
						participant_name= :participant_name, 
						participant_telephone= :participant_telephone, 
						participant_animal= :participant_animal
					WHERE participant_id= :participant_id'
				);
				$query->execute([
					'participant_id' => $participants->getParticipant_id(),
					'participant_name' => $participants->getParticipant_name(),
					'participant_telephone' => $participants->getParticipant_telephone(),
					'participant_animal' => $participants->getParticipant_animal(),
					

					'participant_id' => $participant_id
				]);
				echo $query->rowCount() . " records UPDATED successfully <br>";
			} catch (PDOException $e) {
				$e->getMessage();
			}
		}

	}
?>