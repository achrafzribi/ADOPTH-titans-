<?php 
session_start();

	include("connection.php");
	include("functions.php");


	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		//something was posted
		$event_name    = trim($_POST['event_name']);
		$event_place   = trim($_POST['event_place']);
		$event_date    = trim($_POST['event_date']);
        $event_description = trim($_POST['event_description']);
        $animals   = trim($_POST['animals']);

		if(!empty($event_name))
		{

			//save to database
            $event_id = random_num(20);
			$query = "insert into events (event_name,event_date,event_place,event_description,animals) values ('$event_name','$event_date','$event_place','$event_description','$animals')";

			mysqli_query($con, $query);

			header("Location: afficherListeEvents.php");
			die;
		}else
		{
			echo "Please enter some valid information !";
		}
	}
?>
