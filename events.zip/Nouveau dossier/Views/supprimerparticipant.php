<?php
	include '../Controller/participantC.php';
	$participantC=new participantC();
	$participantC->supprimerparticipant($_GET["participant_id"]);
	header('Location:afficherListeParticipants.php');
?>