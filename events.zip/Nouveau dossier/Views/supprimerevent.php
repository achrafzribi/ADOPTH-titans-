<?php
	include '../Controller/eventC.php';
	$eventC=new eventC();
	$eventC->supprimerevent($_GET["event_name"]);
	header('Location:afficherListeEvents.php');
?>