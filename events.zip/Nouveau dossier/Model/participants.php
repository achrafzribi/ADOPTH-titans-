<?php
	class participants{
		public $participant_id=null;
		public $participant_name=null;
		public $participant_telephone=null;
		public $participant_animal=null;
		
		
		
		private $password=null;
		function __construct($participant_id, $participant_name, $participant_telephone, $participant_animal){
			$this->participant_id=$participant_id;
			$this->participant_name=$participant_name;
			$this->participant_telephone=$participant_telephone;
			$this->participant_animal=$participant_animal;
			
		}
		function getParticipant_id(){
			return $this->participant_id;
		}
		function getParticipant_name(){
			return $this->participant_name;
		}
		function getParticipant_telephone(){
			return $this->participant_telephone;
		}
		function getParticipant_animal(){
			return $this->participant_animal;
		}
		
		
		function setParticipant_name(string $participant_name){
			$this->participant_name=$participant_name;
		}
		function setParticipant_animal(string $participant_animal){
			$this->participant_animal=$participant_animal;
		}
		
		function setParticipant_telephone(string $participant_telephone){
			$this->participant_telephone=$participant_telephone;
		}
		function setParticipant_id(string $participant_id){
			$this->participant_id=$participant_id;
		}
		
		
	}


?>