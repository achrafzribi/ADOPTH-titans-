<?php
	class events{
		public $event_id=null;
		public $event_name=null;
		public $event_date;
		public $animals=null;
		public $event_description=null;
		public $add_date;
		public $event_place=null;
		
		
		public $password=null;
		function __construct($event_id, $event_name, $event_date, $animals, $event_description, $add_date, $event_place){
			$this->event_id=$event_id;
			$this->event_name=$event_name;
			$this->event_date=$event_date;
			$this->animals=$animals;
			$this->event_description=$event_description;
			$this->add_date=$add_date;
			$this->event_place=$event_place;
			
		}
		function getEvent_id(){
			return $this->event_id;
		}
		function getEvent_name(){
			return $this->event_name;
		}
		function getEvent_date(){
			return $this->event_date;
		}
		function getAnimals(){
			return $this->animals;
		}
		function getEvent_description(){
			return $this->event_description;
		}
		function getAdd_date(){
			return $this->add_date;
		}
		function getEvent_place(){
			return $this->event_place;
		}
		
		function setEvent_name(string $event_name){
			$this->event_name=$event_name;
		}
		function setEvent_date(string $event_date){
			$this->event_date=$event_date;
		}
		function setAnimals(string $animals){
			$this->animals=$animals;
		}
		function setEvent_description(string $event_description){
			$this->event_description=$event_description;
		}
		function setAdd_date(string $add_date){
			$this->add_date=$add_date;
		}
		function setEvent_place(string $event_place){
			$this->event_place=$event_place;
		}
		
		
	}


?>