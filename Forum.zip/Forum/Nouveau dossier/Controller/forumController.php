<?php
include_once "config.php";

class forumController {

  public static function ajouter($title,$content,$user){
		$sql="INSERT INTO forums (title, contentForum,dateForum,authorId) 
		VALUES (:title,:content,:dateForum,:id)";
		$db = config::getConnection();
		try{
			$query = $db->prepare($sql);

			$query->execute([
				'title' => $title,
				'content' => $content,
				'dateForum' => date("Y-m-d"),
				'id' => $user,
			]);	
			return 0;
		}
		catch (Exception $e){
			return 2;
			echo 'Erreur: '.$e->getMessage();
		}		
	}

  public static function getSpecificForum($id) {
    $limit = 6;
    $conn = config::getConnection();
    $sql = "select * from Forums where forumId =$id";
    $query = $conn->prepare($sql);
    $query->execute();
    $result = $query->fetchAll();
    return $result;
  }
  function getForum(array $values) {
    $conn = config::getConnection();
    $sql = "select * from Forums inner join Users on authorId = Users.userId where forumId = :id";
    $query = $conn->prepare($sql);
    $query->execute($values);
    $result = $query->fetch();
    return $result;
  }

  function getAllForums() {
    $limit = 6;
    $conn = config::getConnection();
    $sql = "select * from Forums inner join Users on authorId = Users.userId Limit $limit";
    $query = $conn->prepare($sql);
    $query->execute();
    $result = $query->fetchAll();
    return $result;
  }
  function getAllForumsByPage($page) {
    $limit = 6;
    $position = ($page-1) *$limit;

    $conn = config::getConnection();
    $sql = "select * from Forums inner join Users on authorId = Users.userId LIMIT $limit offset $position";
    $query = $conn->prepare($sql);
    $query->execute();
    $result = $query->fetchAll();
    return $result;
  }

  function getRecentForums(int $total) {
    $conn = config::getConnection();
    $sql = "select * from Forums inner join Users on userId = authorId order by dateForum desc limit 0, :total";
    $query = $conn->prepare($sql);
    $query->bindValue(":total", $total, PDO::PARAM_INT);
    $query->execute();
    $result = $query->fetchAll();
    return $result;
  }

  public static function deleteForum(int $id) {
    $sql = "delete from Forums where forumId = :id";
        $db = config::getConnection();
        $req=$db->prepare($sql);
        $req->bindValue(':id',$id);
        try{
            $req->execute();
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    
  }

  public static function editForum($title,$content,$id){
    echo $id;
    $sql="UPDATE forums SET title = :title,contentForum=:content WHERE forumId = $id";
    try {
      $db = config::getConnection();
      $req=$db->prepare($sql);
      
      $req->execute([
        'title' => $title,
        'content' => $content,
      ]);
      
      echo $req->rowCount() . " records UPDATED successfully <br>";
    } catch (PDOException $e) {
      $e->getMessage();
    }
  }

  

}