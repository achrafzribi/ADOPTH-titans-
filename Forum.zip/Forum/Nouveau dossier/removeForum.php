<?php 
require_once('Controller/forumController.php');
    if(isset($_POST['id']) && !empty($_POST['id']))
    {
        forumController::deleteForum($_POST['id']);
        
    }
    header('location:news.php');