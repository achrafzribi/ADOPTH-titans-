<?php
include_once "config.php";

class likeC {

  public static function ajouter($userId,$forumId){
    
		$sql="INSERT INTO likes (userId, forumId) 
		VALUES (:userId,:forumId)";
		$db = config::getConnection();
		try{
			$query = $db->prepare($sql);

			$query->execute([
				'userId' => $userId,
				'forumId' => $forumId
			]);	
			
		}
		catch (Exception $e){
			
			echo 'Erreur: '.$e->getMessage();
		}		
	}

  public static function getSpecific($userId,$forumId) {
    $limit = 6;
    $conn = config::getConnection();
    $sql = "select * from likes where userId =$userId and forumId=$forumId";
    $query = $conn->prepare($sql);
    $query->execute();
    $result = $query->fetchAll();
    return $result;
  }
  public static function getNumber($forumId) {
    $limit = 6;
    $conn = config::getConnection();
    $sql = "select * from likes where forumId=$forumId";
    $query = $conn->prepare($sql);
    $query->execute();
    $result = $query->fetchAll();
    return $result;
  }
  function getForum(array $values) {
    $conn = config::getConnection();
    $sql = "select * from Forums inner join Users on authorId = Users.userId where forumId = :id";
    $query = $conn->prepare($sql);
    $query->execute($values);
    $result = $query->fetch();
    return $result;
  }

  public static function display($id) {
    $conn = config::getConnection();
    $sql = "select * from commentaires c inner join users u on c.userId=u.userId where forumId='$id'";
    $query = $conn->prepare($sql);
    $query->execute();
    $result = $query->fetchAll();
    return $result;
  }
  function getAllForumsByPage($page) {
    $limit = 6;
    $position = ($page-1) *$limit;

    $conn = config::getConnection();
    $sql = "select * from Forums inner join Users on authorId = Users.userId LIMIT $limit offset $position";
    $query = $conn->prepare($sql);
    $query->execute();
    $result = $query->fetchAll();
    return $result;
  }

  function getRecentForums(int $total) {
    $conn = config::getConnection();
    $sql = "select * from Forums inner join Users on userId = authorId order by dateForum desc limit 0, :total";
    $query = $conn->prepare($sql);
    $query->bindValue(":total", $total, PDO::PARAM_INT);
    $query->execute();
    $result = $query->fetchAll();
    return $result;
  }

  public static function delete( $userId,$forumId) {
    $sql = "delete from likes where forumId = :forumId and userId = :userId";
        $db = config::getConnection();
        $req=$db->prepare($sql);
        $req->bindValue(':forumId',$forumId);
        $req->bindValue(':userId',$userId);
        try{
            $req->execute();
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    
  }

  public static function editForum($title,$content,$id){
    echo $id;
    $sql="UPDATE forums SET title = :title,contentForum=:content WHERE forumId = $id";
    try {
      $db = config::getConnection();
      $req=$db->prepare($sql);
      
      $req->execute([
        'title' => $title,
        'content' => $content,
      ]);
      
      echo $req->rowCount() . " records UPDATED successfully <br>";
    } catch (PDOException $e) {
      $e->getMessage();
    }
  }

  

}