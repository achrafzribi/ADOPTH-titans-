<?php 
session_start();

	include("connection.php");
	include("functions.php");


	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		//something was posted
		$product_name    = trim($_POST['product_name']);
        $product_description = trim($_POST['product_description']);
        $quantity     = (int) $_POST['quantity'];
        $product_price   = (float) $_POST['product_price'];

		if(!empty($product_name) && !empty($quantity) && !empty($product_price))
		{

			//save to database
            $product_id = random_num(20);
			$query = "insert into products (product_name,product_description,quantity,product_price) values ('$product_name','$product_description','$quantity','$product_price')";

			mysqli_query($con, $query);

			header("Location: apps-ecommerce-products.php");
			die;
		}else
		{
			echo "Please enter some valid information!";
		}
	}
?>
