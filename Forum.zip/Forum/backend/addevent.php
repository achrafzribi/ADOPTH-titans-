<?php 
session_start();

	include("connection.php");
	include("functions.php");


	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		//something was posted
		$event_name    = trim($_POST['event_name']);
		$event_place   = trim($_POST['event_place']);
		$event_date    = trim($_POST['event_date']);
        $event_description = trim($_POST['event_description']);
        $quantity     = (int) $_POST['quantity'];
        $ticket_price   = (float) $_POST['ticket_price'];

		if(!empty($event_name) && !empty($quantity) && !empty($ticket_price))
		{

			//save to database
            $event_id = random_num(20);
			$query = "insert into events (event_name,event_date,event_place,event_description,quantity,ticket_price) values ('$event_name','$event_date','$event_place','$event_description','$quantity','$ticket_price')";

			mysqli_query($con, $query);

			header("Location: apps-calendar.php");
			die;
		}else
		{
			echo "Please enter some valid information!";
		}
	}
?>
