<?php 
	session_start();

	include("connection.php");
	include("functions.php");

    if(isset($_GET['product_name'])){
        $product_name = $_GET['product_name'];
        $sql ="DELETE FROM `products` WHERE `product_name` = '$product_name' ";

        if($con->query($sql)===TRUE){
            header("Location:apps-ecommerce-products.php");
        }else{ 
            echo " error ";
            echo $product_name ;
        }
    }else{
        header("location:pages-404.html");
    }

	
?>
