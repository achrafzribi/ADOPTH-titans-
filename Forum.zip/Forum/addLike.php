<?php 
require_once("Controller/likeC.php");
if(isset($_POST['userId']))
{
    if(!isset($_POST['remove']))
    likeC::ajouter($_POST['userId'],$_POST['forumId']);
    else{
        likeC::delete($_POST['userId'],$_POST['forumId']);
    }
}

?>
<script>
    window.location="news.php";
</script>