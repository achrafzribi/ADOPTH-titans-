<?php 
require_once('Controller/forumController.php');

    if(isset($_POST['id']) && !empty($_POST['id']))
    {
        forumController::editForum($_POST['title'],$_POST['content'],$_POST['id']);
        
    }
    header('location:news.php');