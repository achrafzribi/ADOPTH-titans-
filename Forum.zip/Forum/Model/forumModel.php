<?php
class Forum {
    private string $title;
    private string $authorId;
    private int $forumId;
    private string $forumContent;
function __construct(string $title, string $authorId, int $fourmId, string $forumContent) {
    $this->title = $title;
    $this->authorId = $authorId;
    $this->forumId = $forumId;
    $this->forumContent = $forumContent;
}

function getTitle() {
    return $this->title;
}
function getForumId() {
    return $this->forumId;
}
function getAuthorId() {
    return $this->authorId;
}

function getForumContent() {
    return $this->forumContent;
}
}
