<?php 
require_once('Controller/commentaireC.php');

    if(isset($_POST['comment']))
    {
        if(!empty($_POST['comment'])){
            
            commentaireC::ajouter($_POST['comment'],$_POST['forum'],$_POST['user']);
            header("location:single-news.php?id=".$_POST['forum']);
        }
    }
