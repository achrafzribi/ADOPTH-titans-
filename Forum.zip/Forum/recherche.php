<?php
require "Controller/forumController.php";
include_once 'Model/forumModel.php';


$forumController=new forumController();



if(isset($_POST["title"]))
    {
        $liste = $forumController->rechercher($_POST["title"]);
        }

?>